module.exports = {
  title: 'do while loops',
  example: function () {
    var i = 0;

    do {
      console.log(i);
      i++; // i = i + 1
    } while (i < 0);
  },

  puzzles:[
  ]
};
