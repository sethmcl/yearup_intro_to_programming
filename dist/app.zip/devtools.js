var page = 'examples/1.html';

chrome.devtools.panels.create('YearUp',
                              null,
                              page,
                              function (panel) {});
